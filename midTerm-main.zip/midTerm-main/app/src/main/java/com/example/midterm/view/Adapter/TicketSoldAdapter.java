package com.example.midterm.view.Adapter;

public class TicketSoldAdapter {
}
